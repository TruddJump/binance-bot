import com.quantpilot.terminal.FuturesApi;
import com.quantpilot.terminal.TerminalEngine;

public final class EngineSelfTest {
    static int n=0;
    static void ok(boolean b){if(!b)throw new AssertionError("test #"+(n+1));n++;}
    static void error(TerminalEngine engine,String command){
        try{engine.run(command);throw new AssertionError("expected error "+command);}
        catch(IllegalArgumentException|IllegalStateException expected){n++;}catch(Exception other){throw new AssertionError(other);}
    }
    public static void main(String[] args)throws Exception{
        TerminalEngine engine=new TerminalEngine(new FuturesApi());
        ok(engine.run("help").contains("spike"));
        ok(engine.run("status").contains("DEMO"));
        ok(engine.run("risk").contains("20"));
        ok(engine.run("risk 80").contains("待确认"));
        ok(engine.run("status").contains("20")); // preview does not change settings
        ok(engine.run("abort").contains("放弃"));
        error(engine,"confirm");
        engine.run("risk 80");ok(engine.run("confirm").contains("80"));
        ok(engine.run("risk").contains("80"));
        error(engine,"risk 600");
        ok(engine.run("env live").contains("confirm LIVE"));
        error(engine,"confirm"); // no abbreviated live acceptance
        ok(engine.run("status").contains("DEMO"));
        engine.run("env live");ok(engine.run("abort").contains("放弃"));
        ok(engine.run("status").contains("DEMO"));
        engine.run("env live");ok(engine.run("confirm LIVE").contains("LIVE"));
        ok(engine.run("status").contains("LIVE"));
        ok(engine.run("env demo").contains("DEMO"));
        ok(engine.run("status").contains("DEMO"));
        ok(engine.run("auth").contains("AUTH"));
        ok(engine.run("logout").contains("清除"));
        System.out.println("OK "+n+" engine checks");
    }
}
