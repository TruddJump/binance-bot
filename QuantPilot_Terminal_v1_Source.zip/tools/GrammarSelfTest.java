import com.quantpilot.terminal.Grammar;
import com.quantpilot.terminal.Sign;

public final class GrammarSelfTest {
    static int passed=0;
    static void check(boolean ok){if(!ok)throw new AssertionError("case #"+(passed+1));passed++;}
    static void fails(String cmd){try{Grammar.parse(cmd);throw new AssertionError("Should reject: "+cmd);}catch(IllegalArgumentException e){passed++;}}
    public static void main(String[] args){
        check(Grammar.parse("  Long  DOGEUSDT  100  0.125 ").verb().equals("long"));
        check(Grammar.parse("market BTCUSDT sell 0.01").size()==3);
        check(Grammar.parse("spike DOGEUSDT short 100 15").size()==4);
        check(Grammar.parse("ladder DOGEUSDT long 500 0.08 0.09 5").size()==6);
        check(Grammar.parse("sl BTCUSDT 60000 mark").verb().equals("sl"));
        check(Grammar.parse("trail BTCUSDT 1.5").size()==2);
        check(Grammar.parse("cancelboth BTCUSDT").verb().equals("cancelboth"));
        check(Grammar.parse("confirm LIVE").arg(0).equals("LIVE"));
        check(Grammar.symbol("dogeusdt").equals("DOGEUSDT"));
        check(Grammar.side("short").equals("SELL"));
        check(Grammar.side("BUY").equals("BUY"));
        check(Grammar.dec("0.0000002").toPlainString().equals("0.0000002"));
        check(Grammar.integer("10",2,10)==10);
        check(Grammar.tif("gtx").equals("GTX"));
        check(Grammar.text().contains("spike"));
        fails("rm -rf /");fails("curl http://evil");fails("market BTCUSDT; rm bad");
        fails("buy DOGEUSDT 1 0.1 | sh");fails("");fails("notacommand");
        try{Grammar.dec("1e9");throw new AssertionError();}catch(IllegalArgumentException e){passed++;}
        try{Grammar.dec("-1");throw new AssertionError();}catch(IllegalArgumentException e){passed++;}
        try{Grammar.symbol("BTCUSDC");throw new AssertionError();}catch(IllegalArgumentException e){passed++;}
        check(Sign.hmac("The quick brown fox jumps over the lazy dog","key").equals("f7bc83f430538424b13298e6aa6fb143ef4d59a14946175997479dbc2d1a3cd8"));
        System.out.println("OK "+passed+" pure Java checks");
    }
}
