package com.quantpilot.terminal;

import org.json.JSONArray;
import org.json.JSONObject;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.Callable;

/** All writes are made ONLY by an explicit confirmed command. No autonomous trading loop. */
public final class TerminalEngine {
    private final FuturesApi api;
    private Pending pending;
    private BigDecimal maxOrder=new BigDecimal("20");
    private static final long CONFIRM_MS=45000;
    private record Pending(String display,Callable<String> action,long at,boolean liveSwitch) {}
    public record Snapshot(int orders,int positions,String positionSummary) {}
    public TerminalEngine(FuturesApi api){this.api=api;}

    public void auth(String key,String secret){pending=null;api.auth(key,secret);}
    public boolean authorized(){return api.authorized();}
    public String environment(){return api.environment().name();}
    public void logout(){api.logout();pending=null;}
    private static String trim(String s){return s.length()>12000?s.substring(0,12000)+"\n...（内容已截断）":s;}
    private static String compact(JSONObject x){return trim(x.toString(2));}
    private static String compact(JSONArray x){return trim(x.toString(2));}
    private static String prettyPos(JSONObject p){
        BigDecimal qty=new BigDecimal(p.optString("positionAmt","0"));
        return p.optString("symbol")+" "+(qty.signum()>0?"LONG ":"SHORT ")+qty.abs().toPlainString()+
          " entry="+p.optString("entryPrice","?")+" mark="+p.optString("markPrice","?")+
          " pnl="+p.optString("unRealizedProfit","?");
    }
    public Snapshot snapshot()throws Exception{
        if(!api.authorized())return new Snapshot(-1,-1,"未连接 · 输入 auth");
        JSONArray simple=api.arr("/fapi/v1/openOrders",FuturesApi.params());
        JSONArray algo=api.arr("/fapi/v1/openAlgoOrders",FuturesApi.params());
        JSONArray positions=api.arr("/fapi/v2/positionRisk",FuturesApi.params());
        int count=0;StringBuilder sb=new StringBuilder();
        for(int i=0;i<positions.length();i++){
            JSONObject p=positions.getJSONObject(i);
            if(new BigDecimal(p.optString("positionAmt","0")).signum()==0)continue;
            count++;
            if(sb.length()<180){if(sb.length()>0)sb.append("\n");sb.append(prettyPos(p));}
        }
        if(count==0)sb.append("无持仓");
        if(count>3)sb.append("\n更多请用 positions 查看");
        return new Snapshot(simple.length()+algo.length(),count,sb.toString());
    }
    private String preview(String title,Callable<String> work){
        pending=new Pending(title,work,System.currentTimeMillis(),false);
        return "待确认 [45秒] " + title + "\n输入 confirm 提交，abort 取消。"+
            (api.environment()==FuturesApi.Environment.LIVE?"\n!!! 当前为 LIVE 主网真实资金 !!!":"\n[DEMO 模拟资金]");
    }
    private static String needSymbol(Grammar.Cmd c,int min,int max){Grammar.count(c,min,max);return Grammar.symbol(c.arg(0));}
    private String obj(String path,Map<String,String> p)throws Exception{return compact(api.obj("GET",path,p,true));}
    private String array(String path,Map<String,String> p)throws Exception{return compact(api.arr(path,p));}
    private static String number(BigDecimal d){return d.stripTrailingZeros().toPlainString();}
    private static String usage(Grammar.Cmd c){
        return switch(c.verb()){
           case "long","short","buy","sell" -> "用法: long/short SYMBOL 数量 价格 (Maker GTX)";
           case "limit" -> "用法: limit SYMBOL buy|sell 数量 价格 [gtx|gtc|ioc|fok]";
           case "market" -> "用法: market SYMBOL buy|sell 数量";
           case "close" -> "用法: close SYMBOL all|数量 market|价格";
           case "spike" -> "用法: spike SYMBOL long|short 数量 偏离百分比(0.1~50)";
           case "ladder" -> "用法: ladder SYMBOL long|short 总数量 起始价格 结束价格 2~10档";
           case "sl","tp" -> "用法: "+c.verb()+" SYMBOL 触发价 [mark|last]";
           case "trail" -> "用法: trail SYMBOL 回调百分比0.1~10 [激活价]";
           case "risk" -> "用法: risk [新单名义本金上限USDT，最大500]";
           case "env" -> "用法: env demo|live；live 必须额外 confirm LIVE";
           default -> "用法: "+c.verb()+"；输入 help";
        };
    }
    private static void positiveLimit(BigDecimal d,BigDecimal min,BigDecimal max,String label){
        if(d.compareTo(min)<0||d.compareTo(max)>0)throw new IllegalArgumentException(label+" 必须在 "+min+" ~ "+max+" 之间");
    }
    public String run(String raw)throws Exception{
        Grammar.Cmd c=Grammar.parse(raw);
        try{return handle(c);}catch(IndexOutOfBoundsException | NumberFormatException e){throw new IllegalArgumentException(usage(c));}
    }
    private String handle(Grammar.Cmd c)throws Exception{
        switch(c.verb()){
            case "help": {
                if(c.size()==0)return Grammar.text();
                if(c.size()!=1)throw new IllegalArgumentException("help [trade|query|risk]");
                return switch(c.arg(0).toLowerCase(Locale.ROOT)){
                    case "trade" -> "开仓: long DOGEUSDT 100 0.1 | short DOGEUSDT 100 0.2\n"+
                      "limit DOGEUSDT buy 100 0.1 gtc\nmarket DOGEUSDT sell 100\n"+
                      "spike DOGEUSDT short 100 18 (标记价上方18%限价埋伏)\n"+
                      "ladder DOGEUSDT long 500 0.09 0.08 5\n"+
                      "close DOGEUSDT all market\nsl DOGEUSDT 0.08 mark\ntp DOGEUSDT 0.11 last\ntrail DOGEUSDT 1.5";
                    case "query" -> "orders [SYMBOL] · algos [SYMBOL] · position SYMBOL · balance · price SYMBOL\n"+
                      "order SYMBOL ID · algo SYMBOL ID · history SYMBOL · fills SYMBOL · income SYMBOL";
                    case "risk" -> "每笔需手动 confirm；demo 默认。切 live 需 confirm LIVE 后重新 auth。\n"+
                      "风险额 risk 20 (USDT名义本金)；每笔最大500；无自动止损。\n"+
                      "cancelboth SYMBOL 普通单和条件单都撤；flatten SYMBOL 先撤单后市价平仓。";
                    default -> "未知帮助分类。help [trade|query|risk]";
                };
            }
            case "clear":return "\u0001CLEAR";
            case "auth":return "\u0001AUTH";
            case "logout":logout();return "凭据从进程内存清除；持仓/挂单仍在币安，未撤销";
            case "env": {
                Grammar.count(c,1,1);
                String env=c.arg(0).toLowerCase(Locale.ROOT);
                if(env.equals("demo")){api.env(FuturesApi.Environment.DEMO);pending=null;return "已切换 DEMO；原 Key 已清空，请重新 auth";}
                if(!env.equals("live"))throw new IllegalArgumentException(usage(c));
                pending=new Pending("切换到真实资金 LIVE 主网",()->{
                    api.env(FuturesApi.Environment.LIVE);
                    return "已进入 LIVE 真实资金环境；凭据已清空，必须重新 auth";
                },System.currentTimeMillis(),true);
                return "高风险操作：切换 LIVE，真实资金下单可能造成全部本金损失。\n"+
                   "45秒内输入 confirm LIVE 才切换；其他输入不会切换。";
            }
            case "abort":pending=null;return "已放弃待确认操作";
            case "confirm": {
                if(pending==null)throw new IllegalArgumentException("当前没有待确认操作");
                Pending x=pending;pending=null; // Clear BEFORE network call: never replay after timeout
                if(System.currentTimeMillis()-x.at()>CONFIRM_MS)throw new IllegalStateException("确认超时，未提交任何操作");
                if(x.liveSwitch() && (c.size()!=1||!c.arg(0).equals("LIVE")))
                    throw new IllegalArgumentException("主网切换必须完整输入 confirm LIVE；已取消");
                if(!x.liveSwitch()&&c.size()!=0)throw new IllegalArgumentException("订单确认仅接受 confirm；已取消");
                try{return "执行回执：\n"+x.action().call();}
                catch(Exception e){throw new IllegalStateException(e.getMessage()+
                    "\n注意：如果网络超时，订单可能已被交易所接收；先查 orders / history，禁止直接重发。",e);}
            }
            case "status":{
                return "环境="+api.environment()+"；凭据="+(api.authorized()?"内存已配置":"未配置")+
                   "；新开仓名义额上限="+maxOrder+" USDT\n"+
                   "自动交易=关闭；仅响应终端命令；后台持续运行=不支持\n"+
                   "待确认="+(pending==null?"无":pending.display());
            }
            case "risk": {
                if(c.size()==0)return "单笔新增风险名义本金上限 "+maxOrder+" USDT；不等于最大亏损";
                Grammar.count(c,1,1);
                BigDecimal n=Grammar.dec(c.arg(0));positiveLimit(n,new BigDecimal("5"),new BigDecimal("500"),"限额");
                return preview("调整新开仓单笔名义本金上限为 "+n+" USDT",()->{
                    maxOrder=n;return "新限制="+n+" USDT （仅本次进程生效）";
                });
            }
            case "ping":return api.request("GET","/fapi/v1/ping",FuturesApi.params(),false);
            case "time":return api.request("GET","/fapi/v1/time",FuturesApi.params(),false);
            case "positionmode":return obj("/fapi/v1/positionSide/dual",FuturesApi.params());
            case "balance":return array("/fapi/v3/balance",FuturesApi.params());
            case "positions":return positions(null);
            case "position":return positions(needSymbol(c,1,1));
            case "orders":return array("/fapi/v1/openOrders",symbolOpt(c));
            case "algos":return array("/fapi/v1/openAlgoOrders",symbolOpt(c));
            case "order":{
                String s=needSymbol(c,2,2);return obj("/fapi/v1/order",FuturesApi.params("symbol",s,"orderId",id(c.arg(1))));
            }
            case "algo":{
                String s=needSymbol(c,2,2);return obj("/fapi/v1/algoOrder",FuturesApi.params("symbol",s,"algoId",id(c.arg(1))));
            }
            case "history":return array("/fapi/v1/allOrders",FuturesApi.params("symbol",needSymbol(c,1,1),"limit","20"));
            case "fills":return array("/fapi/v1/userTrades",FuturesApi.params("symbol",needSymbol(c,1,1),"limit","20"));
            case "income":return array("/fapi/v1/income",FuturesApi.params("symbol",needSymbol(c,1,1),"limit","20"));
            case "price":return compact(api.obj("GET","/fapi/v1/ticker/price",FuturesApi.params("symbol",needSymbol(c,1,1)),false));
            case "mark":return compact(api.obj("GET","/fapi/v1/premiumIndex",FuturesApi.params("symbol",needSymbol(c,1,1)),false));
            case "book":return compact(api.obj("GET","/fapi/v1/ticker/bookTicker",FuturesApi.params("symbol",needSymbol(c,1,1)),false));
            case "funding":return compact(api.obj("GET","/fapi/v1/premiumIndex",FuturesApi.params("symbol",needSymbol(c,1,1)),false));
            case "rules":return compact(api.info(needSymbol(c,1,1)));
            case "refresh":return "\u0001REFRESH";
            case "long":case "short":case "buy":case "sell":{
                String s=needSymbol(c,3,3);
                BigDecimal qty=Grammar.dec(c.arg(1)),price=Grammar.dec(c.arg(2));
                String side=(c.verb().equals("long")||c.verb().equals("buy"))?"BUY":"SELL";
                return newLimit(s,side,qty,price,"GTX");
            }
            case "limit":{
                String s=needSymbol(c,4,5),side=Grammar.side(c.arg(1));
                BigDecimal qty=Grammar.dec(c.arg(2)),price=Grammar.dec(c.arg(3));
                String tif=c.size()==5?Grammar.tif(c.arg(4)):"GTX";
                return newLimit(s,side,qty,price,tif);
            }
            case "market":{
                String s=needSymbol(c,3,3),side=Grammar.side(c.arg(1));
                BigDecimal qty=Grammar.dec(c.arg(2));
                return preview("市价开仓 "+s+" "+side+" 数量="+qty+"；实际成交价不可保证；限额="+maxOrder,
                   ()->compact(api.placeMarket(s,side,qty,false,maxOrder)));
            }
            case "close":{
                String s=needSymbol(c,3,3),q=c.arg(1),px=c.arg(2);
                boolean all=q.equalsIgnoreCase("all");
                BigDecimal wanted=all?null:Grammar.dec(q);
                boolean market=px.equalsIgnoreCase("market");
                BigDecimal price=market?null:Grammar.dec(px);
                return preview("只减仓平仓 "+s+" "+q+" "+px+" (按实际持仓确定方向)",()->{
                    BigDecimal pos=api.positionAmt(s);
                    if(pos.signum()==0)throw new IllegalStateException("没有可平持仓");
                    BigDecimal quantity=all?pos.abs():wanted;
                    if(quantity.compareTo(pos.abs())>0)throw new IllegalStateException("平仓数量超过实际仓位 "+pos.abs());
                    String side=pos.signum()>0?"SELL":"BUY";
                    return compact(market?api.placeMarket(s,side,quantity,true,maxOrder):
                        api.placeLimit(s,side,quantity,price,"GTX",true,maxOrder));
                });
            }
            case "spike":{
                String s=needSymbol(c,4,4),side=Grammar.side(c.arg(1));
                BigDecimal qty=Grammar.dec(c.arg(2)),pct=Grammar.dec(c.arg(3));
                positiveLimit(pct,new BigDecimal("0.1"),new BigDecimal("50"),"偏离百分比");
                JSONObject mark=api.obj("GET","/fapi/v1/premiumIndex",FuturesApi.params("symbol",s),false);
                BigDecimal mid=new BigDecimal(mark.getString("markPrice"));
                BigDecimal multiplier=BigDecimal.ONE.add((side.equals("BUY")?pct.negate():pct).divide(new BigDecimal("100"),10,RoundingMode.HALF_UP));
                BigDecimal exact=mid.multiply(multiplier);
                BigDecimal target=FuturesApi.quantize(exact,api.tick(s),side.equals("SELL"));
                if(target.signum()<=0)throw new IllegalArgumentException("挂单价格必须大于0");
                return newLimit(s,side,qty,target,"GTX");
            }
            case "ladder":{
                String s=needSymbol(c,6,6),side=Grammar.side(c.arg(1));
                BigDecimal total=Grammar.dec(c.arg(2)),from=Grammar.dec(c.arg(3)),to=Grammar.dec(c.arg(4));
                int n=Grammar.integer(c.arg(5),2,10);
                return ladder(s,side,total,from,to,n);
            }
            case "sl":case "tp":{
                String s=needSymbol(c,2,3);
                BigDecimal trigger=Grammar.dec(c.arg(1));
                String working=triggerType(c.size()==3?c.arg(2):"mark");
                String type=c.verb().equals("sl")?"STOP_MARKET":"TAKE_PROFIT_MARKET";
                return preview(type+" "+s+" 触发="+trigger+" "+working+"；全仓触发平仓（非保证成交价）",
                  ()->compact(api.protection(s,type,trigger,working,null,null)));
            }
            case "trail":{
                String s=needSymbol(c,2,3);
                BigDecimal callback=Grammar.dec(c.arg(1));
                positiveLimit(callback,new BigDecimal("0.1"),new BigDecimal("10"),"回调率");
                BigDecimal activation=c.size()==3?Grammar.dec(c.arg(2)):null;
                return preview("跟踪止损 "+s+" callback="+callback+"% qty=当前持仓全量；激活="+(activation==null?"即时":activation),
                  ()->compact(api.protection(s,"TRAILING_STOP_MARKET",null,"CONTRACT_PRICE",callback,activation)));
            }
            case "cancel":{
                String s=needSymbol(c,2,2),i=id(c.arg(1));
                return preview("撤销普通委托 "+s+" #"+i,()->compact(api.obj("DELETE","/fapi/v1/order",
                    FuturesApi.params("symbol",s,"orderId",i),true)));
            }
            case "cancelall":{
                String s=needSymbol(c,1,1);
                return preview("撤销 "+s+" 所有普通委托（不含条件单）",()->compact(api.obj("DELETE","/fapi/v1/allOpenOrders",
                  FuturesApi.params("symbol",s),true)));
            }
            case "cancelalgo":{
                String s=needSymbol(c,2,2),i=id(c.arg(1));
                return preview("撤销条件单 "+s+" #"+i,()->compact(api.obj("DELETE","/fapi/v1/algoOrder",
                  FuturesApi.params("symbol",s,"algoId",i),true)));
            }
            case "cancelalgos":{
                String s=needSymbol(c,1,1);
                return preview("撤销 "+s+" 全部条件单（可能移除止损！）",()->compact(api.obj("DELETE","/fapi/v1/algoOpenOrders",
                  FuturesApi.params("symbol",s),true)));
            }
            case "cancelboth":{
                String s=needSymbol(c,1,1);
                return preview("撤销 "+s+" 所有普通单和保护条件单（持仓可能失去止损！）",()->{
                    String x=compact(api.obj("DELETE","/fapi/v1/allOpenOrders",FuturesApi.params("symbol",s),true));
                    String y=compact(api.obj("DELETE","/fapi/v1/algoOpenOrders",FuturesApi.params("symbol",s),true));
                    return "普通单 "+x+"\n条件单 "+y;
                });
            }
            case "flatten":{
                String s=needSymbol(c,1,1);
                return preview("紧急清理 "+s+"：先撤普通单+条件单，再市价减仓平掉当前持仓",()->{
                    String x=compact(api.obj("DELETE","/fapi/v1/allOpenOrders",FuturesApi.params("symbol",s),true));
                    String y=compact(api.obj("DELETE","/fapi/v1/algoOpenOrders",FuturesApi.params("symbol",s),true));
                    BigDecimal pos=api.positionAmt(s);
                    if(pos.signum()==0)return "已撤委托，当前无仓位。普通单 "+x+"\n条件单 "+y;
                    String side=pos.signum()>0?"SELL":"BUY";
                    String z=compact(api.placeMarket(s,side,pos.abs(),true,maxOrder));
                    return "撤单完成；平仓订单回执 "+z+"\n请马上用 position "+s+" 核实是否全部成交";
                });
            }
            case "leverage":{
                String s=needSymbol(c,2,2);int n=Grammar.integer(c.arg(1),1,10);
                return preview("设置 "+s+" 杠杆 "+n+"x (上限10x)",()->compact(api.obj("POST","/fapi/v1/leverage",
                  FuturesApi.params("symbol",s,"leverage",Integer.toString(n)),true)));
            }
            case "margin":{
                String s=needSymbol(c,2,2),m=c.arg(1).toLowerCase(Locale.ROOT);
                if(!m.equals("isolated")&&!m.equals("cross"))throw new IllegalArgumentException("只能 isolated 或 cross");
                String apiMode=m.equals("isolated")?"ISOLATED":"CROSSED";
                return preview("更改 "+s+" 保证金模式 "+apiMode,()->compact(api.obj("POST","/fapi/v1/marginType",
                  FuturesApi.params("symbol",s,"marginType",apiMode),true)));
            }
            default:throw new IllegalArgumentException("未实现命令："+c.verb());
        }
    }
    private String newLimit(String s,String side,BigDecimal qty,BigDecimal price,String tif){
        return preview("限价开仓 "+s+" "+side+" "+qty+" @"+price+" "+tif+
          " 名义本金="+number(qty.multiply(price))+" USDT",
          ()->compact(api.placeLimit(s,side,qty,price,tif,false,maxOrder)));
    }
    private String ladder(String s,String side,BigDecimal total,BigDecimal from,BigDecimal to,int count)throws Exception{
        JSONObject symbolInfo=api.info(s);
        JSONObject lot=FuturesApi.filter(symbolInfo,"LOT_SIZE");
        BigDecimal step=new BigDecimal(lot.getString("stepSize"));
        BigDecimal unit=FuturesApi.quantize(total.divide(BigDecimal.valueOf(count),14,RoundingMode.DOWN),step,false);
        if(unit.signum()<=0)throw new IllegalArgumentException("每档数量低于步长");
        BigDecimal tick=api.tick(s);
        List<BigDecimal> prices=new ArrayList<>();
        for(int i=0;i<count;i++){
            BigDecimal fraction=BigDecimal.valueOf(i).divide(BigDecimal.valueOf(count-1),14,RoundingMode.HALF_UP);
            BigDecimal raw=from.add(to.subtract(from).multiply(fraction));
            BigDecimal price=FuturesApi.quantize(raw,tick,side.equals("SELL"));
            if(prices.contains(price))throw new IllegalArgumentException("档距小于最小价格步长，出现重复档位");
            prices.add(price);
        }
        BigDecimal amount=BigDecimal.ZERO;
        for(BigDecimal p:prices){api.validate(s,"LIMIT",unit,p,true,maxOrder);amount=amount.add(unit.multiply(p));}
        if(amount.compareTo(maxOrder)>0)throw new IllegalArgumentException("多档总名义本金 "+number(amount)+" 超过 limit="+maxOrder+" USDT");
        String label="阶梯挂单 "+s+" "+side+" 每档="+unit+" 共"+count+"档 价格="+prices+" 总名义本金="+number(amount);
        return preview(label,()->{
            api.oneWay();api.ensureOpeningSide(s,side);
            StringBuilder out=new StringBuilder();int done=0;
            for(BigDecimal p:prices){
                try{
                    JSONObject r=api.placeLimit(s,side,unit,p,"GTX",false,maxOrder);
                    done++;out.append("\n").append(p).append(" -> orderId=").append(r.optString("orderId","?"));
                }catch(Exception e){
                    return "部分执行：成功"+done+"/"+count+"档；失败档="+p+" 原因="+e.getMessage()+
                      "。其他档位未继续发送；必须查询 orders 核对："+out;
                }
            }
            return "下单响应成功 "+done+"/"+count+"档（不表示已成交）"+out;
        });
    }
    private String positions(String target)throws Exception{
        JSONArray a=api.arr("/fapi/v2/positionRisk",target==null?FuturesApi.params():FuturesApi.params("symbol",target));
        StringBuilder out=new StringBuilder();int count=0;
        for(int i=0;i<a.length();i++){
            JSONObject p=a.getJSONObject(i);
            BigDecimal amount=new BigDecimal(p.optString("positionAmt","0"));
            if(amount.signum()==0)continue;
            out.append(prettyPos(p)).append("\n");count++;
        }
        return count==0?"无非零持仓":count+" 个持仓\n"+out;
    }
    private static Map<String,String> symbolOpt(Grammar.Cmd c){
        if(c.size()==0)return FuturesApi.params();
        Grammar.count(c,1,1);return FuturesApi.params("symbol",Grammar.symbol(c.arg(0)));
    }
    private static String triggerType(String s){
        if(s.equalsIgnoreCase("mark"))return "MARK_PRICE";
        if(s.equalsIgnoreCase("last"))return "CONTRACT_PRICE";
        throw new IllegalArgumentException("触发价选 mark 或 last");
    }
    private static String id(String s){
        if(!s.matches("[0-9]{1,22}"))throw new IllegalArgumentException("ID 必须是交易所返回的数字 orderId/algoId");
        return s;
    }
}
