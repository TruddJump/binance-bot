package com.quantpilot.terminal;

import android.app.Activity;
import android.app.AlertDialog;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.InputType;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.view.WindowManager;
import android.view.inputmethod.EditorInfo;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicBoolean;

/** Intentionally one screen: count, positions, console and one text input. */
public final class MainActivity extends Activity {
    private final ExecutorService queue=Executors.newSingleThreadExecutor();
    private final Handler main=new Handler(Looper.getMainLooper());
    private final AtomicBoolean busy=new AtomicBoolean(false);
    private final FuturesApi api=new FuturesApi();
    private final TerminalEngine engine=new TerminalEngine(api);
    private TextView count, positions, output;
    private EditText command;
    private ScrollView scroll;
    private boolean resumed=false;
    private static final int BG=0xFF0C1118, PANEL=0xFF131D29, LIGHT=0xFFD5DFED, GREEN=0xFF75E0BB;
    private final Runnable heartbeat=new Runnable(){
        @Override public void run(){
            if(!resumed)return;
            updateSnapshot();
            main.postDelayed(this,30000);
        }
    };
    @Override public void onCreate(Bundle state){
        super.onCreate(state);
        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_SECURE,WindowManager.LayoutParams.FLAG_SECURE);
        LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(14),dp(14),dp(14),dp(12));root.setBackgroundColor(BG);
        count=terminalText(14,true);
        count.setText("当前委托  --  · DEMO");root.addView(count);
        positions=terminalText(13,false);
        positions.setTextColor(0xFFA7BCDF);positions.setText("当前持仓  未连接");
        positions.setPadding(0,dp(8),0,dp(10));
        root.addView(positions);
        View line=new View(this);line.setBackgroundColor(0xFF27374B);
        root.addView(line,new LinearLayout.LayoutParams(-1,dp(1)));
        scroll=new ScrollView(this);scroll.setFillViewport(true);
        output=terminalText(13,false);
        output.setTextColor(LIGHT);output.setTextIsSelectable(true);
        output.setPadding(dp(2),dp(12),dp(2),dp(18));
        scroll.addView(output);
        root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
        command=new EditText(this);
        command.setSingleLine(true);command.setTextSize(14);
        command.setTypeface(Typeface.MONOSPACE);
        command.setTextColor(GREEN);command.setHintTextColor(0xFF71849B);
        command.setHint("> help  |  输入命令后回车");command.setBackgroundColor(PANEL);
        command.setPadding(dp(12),dp(13),dp(12),dp(13));
        command.setInputType(InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);
        command.setImeOptions(EditorInfo.IME_ACTION_SEND);
        command.setOnEditorActionListener((v,action,event)->{
            boolean enter=event!=null&&event.getKeyCode()==KeyEvent.KEYCODE_ENTER&&event.getAction()==KeyEvent.ACTION_DOWN;
            if(action==EditorInfo.IME_ACTION_SEND||enter){submit();return true;}return false;
        });
        root.addView(command,new LinearLayout.LayoutParams(-1,-2));
        setContentView(root);
        append("QuantPilot Terminal v1\nDEMO 是默认环境。没有自动交易、没有后台策略。\n输入 help 查看全部命令；auth 通过安全输入框连接 API。\n所有交易、撤单、止损和配置修改必须 confirm。\n");
    }
    private int dp(float v){return (int)(v*getResources().getDisplayMetrics().density+.5f);}
    private TextView terminalText(int sp,boolean bold){
        TextView t=new TextView(this);
        t.setTextSize(sp);t.setTypeface(Typeface.MONOSPACE,bold?Typeface.BOLD:Typeface.NORMAL);
        t.setTextColor(GREEN);t.setGravity(Gravity.START);
        return t;
    }
    private void submit(){
        String raw=command.getText().toString().trim();
        if(raw.isEmpty())return;
        if(!busy.compareAndSet(false,true)){append("命令仍在执行，请勿重复提交。\n");return;}
        command.setText("");
        append("> "+raw+"\n");
        queue.execute(()->{
            try{
                String result=engine.run(raw);
                if(result.equals("\u0001AUTH")){main.post(this::credentialDialog);}
                else if(result.equals("\u0001CLEAR")){main.post(()->output.setText(""));}
                else if(result.equals("\u0001REFRESH")){main.post(this::updateSnapshot);}
                else {main.post(()->append(result+"\n\n"));}
                if(raw.equalsIgnoreCase("confirm")||raw.equals("confirm LIVE")||raw.startsWith("env ")||raw.equals("logout"))
                    main.post(this::updateSnapshot);
            }catch(Exception err){
                main.post(()->append("错误："+err.getMessage()+"\n\n"));
            }finally{busy.set(false);}
        });
    }
    private void append(String s){
        String current=output.getText().toString();
        if(current.length()>35000)current=current.substring(Math.min(current.length(),15000));
        output.setText(current+s);
        scroll.post(()->scroll.fullScroll(View.FOCUS_DOWN));
    }
    private void credentialDialog(){
        LinearLayout column=new LinearLayout(this);
        column.setOrientation(LinearLayout.VERTICAL);
        column.setPadding(dp(20),dp(10),dp(20),0);
        EditText key=new EditText(this);key.setSingleLine(true);key.setHint("API Key");
        key.setInputType(InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_VARIATION_PASSWORD);
        EditText secret=new EditText(this);secret.setSingleLine(true);secret.setHint("API Secret");
        secret.setInputType(InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_VARIATION_PASSWORD);
        column.addView(key);column.addView(secret);
        new AlertDialog.Builder(this)
          .setTitle("配置 "+engine.environment()+" API（仅保存在进程内存）")
          .setView(column)
          .setMessage("必须使用对应环境密钥，禁用提现权限。关闭或重启应用需重新认证。")
          .setPositiveButton("连接",(dialog,which)->{
              try{engine.auth(key.getText().toString(),secret.getText().toString());
                  key.setText("");secret.setText("");
                  append("已配置 "+engine.environment()+" API 凭据（仅内存）；正在刷新账户状态。\n");
                  updateSnapshot();
              }catch(Exception ex){append("认证输入无效："+ex.getMessage()+"\n");}
          }).setNegativeButton("取消",null).show();
    }
    private void updateSnapshot(){
        if(!resumed)return;
        if(!engine.authorized()){
            count.setText("当前委托  --  · "+engine.environment());
            count.setTextColor(engine.environment().equals("LIVE")?0xFFFF977E:GREEN);
            positions.setText("当前持仓  未连接，输入 auth");return;
        }
        queue.execute(()->{
            try{
                TerminalEngine.Snapshot s=engine.snapshot();
                main.post(()->{
                    count.setText("当前委托  "+s.orders()+"（普通+条件） · "+engine.environment());
                    count.setTextColor(engine.environment().equals("LIVE")?0xFFFF977E:GREEN);
                    positions.setText("当前持仓  "+s.positions()+"\n"+s.positionSummary());
                });
            }catch(Exception err){
                main.post(()->{
                    count.setText("当前委托  ?（刷新失败） · "+engine.environment());
                    count.setTextColor(engine.environment().equals("LIVE")?0xFFFF977E:GREEN);
                    positions.setText("当前持仓  ?（刷新失败；输入 refresh 重试）");
                    append("状态刷新失败："+err.getMessage()+"\n");
                });
            }
        });
    }
    @Override protected void onResume(){super.onResume();resumed=true;main.removeCallbacks(heartbeat);main.post(heartbeat);}
    @Override protected void onPause(){resumed=false;main.removeCallbacks(heartbeat);super.onPause();}
    @Override protected void onDestroy(){main.removeCallbacks(heartbeat);queue.shutdownNow();engine.logout();super.onDestroy();}
}
