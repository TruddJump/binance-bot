package com.quantpilot.terminal;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.math.BigDecimal;
import java.net.HttpURLConnection;
import java.net.URLEncoder;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.UUID;

/** Binance USDT-M only. No generic URL/path execution, no withdrawal endpoint. */
public final class FuturesApi {
    public enum Environment { DEMO, LIVE }
    private Environment environment=Environment.DEMO;
    private String key="",secret="";
    private long serverOffsetMs=0, syncedAt=0;
    private JSONObject marketInfo;
    private long marketInfoAt=0;

    public synchronized Environment environment(){return environment;}
    public synchronized boolean authorized(){return !key.isEmpty()&&!secret.isEmpty();}
    public synchronized void env(Environment e){environment=e;logout();marketInfo=null;marketInfoAt=0;}
    public synchronized void auth(String k,String s){
        if(k==null||s==null||k.isBlank()||s.isBlank())throw new IllegalArgumentException("Key 与 Secret 不能为空");
        key=k.trim();secret=s.trim();syncedAt=0;
    }
    public synchronized void logout(){key="";secret="";syncedAt=0;}
    private String host(){return environment==Environment.DEMO?"https://demo-fapi.binance.com":"https://fapi.binance.com";}
    public static LinkedHashMap<String,String> params(String... values){
        LinkedHashMap<String,String> out=new LinkedHashMap<>();
        for(int i=0;i<values.length;i+=2)out.put(values[i],values[i+1]);
        return out;
    }
    private static String qs(Map<String,String> m){
        StringBuilder b=new StringBuilder();
        for(Map.Entry<String,String> e:m.entrySet()){
            if(b.length()>0)b.append('&');
            b.append(URLEncoder.encode(e.getKey(),StandardCharsets.UTF_8));b.append('=');
            b.append(URLEncoder.encode(e.getValue(),StandardCharsets.UTF_8));
        }
        return b.toString();
    }
    private static String str(InputStream is)throws Exception{
        if(is==null)return "";
        try(InputStream in=is;ByteArrayOutputStream baos=new ByteArrayOutputStream()){
            byte[] a=new byte[4096];int n;
            while((n=in.read(a))!=-1){baos.write(a,0,n);if(baos.size()>2000000)throw new IllegalStateException("响应过大");}
            return baos.toString(StandardCharsets.UTF_8);
        }
    }
    private String raw(String method,String path,Map<String,String> p,boolean signed)throws Exception{
        if(!path.matches("/fapi/(?:v1|v2|v3)/[a-zA-Z0-9/]+"))throw new SecurityException("禁止的 API 路径");
        LinkedHashMap<String,String> all=new LinkedHashMap<>(p);
        String useKey;
        if(signed){
            if(!authorized())throw new IllegalStateException("未认证。输入 auth 并填写当前环境的 API Key / Secret");
            if(!path.equals("/fapi/v1/time")&&(System.currentTimeMillis()-syncedAt>600000))syncTime();
            all.put("recvWindow","5000");
            all.put("timestamp",Long.toString(System.currentTimeMillis()+serverOffsetMs));
            all.put("signature",Sign.hmac(qs(all),secret));
        }
        useKey=key;
        String query=qs(all);
        boolean post=method.equals("POST");
        URL url=new URL(host()+path+(post?"":query.isEmpty()?"":"?"+query));
        HttpURLConnection c=(HttpURLConnection)url.openConnection();
        c.setRequestMethod(method);c.setConnectTimeout(7000);c.setReadTimeout(11000);
        c.setRequestProperty("User-Agent","QuantPilotTerminal/1.0");
        c.setRequestProperty("Accept","application/json");
        if(signed)c.setRequestProperty("X-MBX-APIKEY",useKey);
        if(post){
            c.setDoOutput(true);c.setRequestProperty("Content-Type","application/x-www-form-urlencoded");
            try(OutputStream out=c.getOutputStream()){out.write(query.getBytes(StandardCharsets.UTF_8));}
        }
        try{
            int status=c.getResponseCode();
            String result=str(status>=400?c.getErrorStream():c.getInputStream());
            if(status>=400){
                String err=result.length()>600?result.substring(0,600):result;
                throw new IllegalStateException("Binance HTTP "+status+"："+err);
            }
            return result;
        }finally{c.disconnect();}
    }
    private synchronized void syncTime()throws Exception{
        String data=raw("GET","/fapi/v1/time",params(),false);
        serverOffsetMs=new JSONObject(data).getLong("serverTime")-System.currentTimeMillis();
        syncedAt=System.currentTimeMillis();
    }
    public synchronized String request(String method,String path,Map<String,String> params,boolean signed)throws Exception{
        return raw(method,path,params,signed);
    }
    public synchronized JSONObject obj(String method,String path,Map<String,String> p,boolean signed)throws Exception{
        return new JSONObject(request(method,path,p,signed));
    }
    public synchronized JSONArray arr(String path,Map<String,String> p)throws Exception{
        return new JSONArray(request("GET",path,p,true));
    }
    public synchronized JSONObject info(String symbol)throws Exception{
        if(marketInfo==null||System.currentTimeMillis()-marketInfoAt>300000){
            marketInfo=obj("GET","/fapi/v1/exchangeInfo",params(),false);marketInfoAt=System.currentTimeMillis();
        }
        JSONArray a=marketInfo.getJSONArray("symbols");
        for(int i=0;i<a.length();i++){
            JSONObject item=a.getJSONObject(i);
            if(item.getString("symbol").equals(symbol)){
                if(!item.optString("status").equals("TRADING") ||
                        !item.optString("contractType").equals("PERPETUAL")||
                        !item.optString("quoteAsset").equals("USDT"))
                    throw new IllegalArgumentException("非可交易 USDT 永续合约");
                return item;
            }
        }
        throw new IllegalArgumentException("合约不存在: "+symbol);
    }
    public static JSONObject filter(JSONObject info,String kind)throws Exception{
        JSONArray list=info.getJSONArray("filters");
        for(int i=0;i<list.length();i++){
            JSONObject item=list.getJSONObject(i);
            if(item.getString("filterType").equals(kind))return item;
        }
        throw new IllegalArgumentException("交易对缺少规则 "+kind);
    }
    private static BigDecimal dec(JSONObject o,String name){return new BigDecimal(o.getString(name));}
    private static void range(BigDecimal x,BigDecimal min,BigDecimal max,String label){
        if(x.compareTo(min)<0||(max.signum()>0&&x.compareTo(max)>0))
            throw new IllegalArgumentException(label+" 超出允许范围 ["+min+", "+max+"]");
    }
    public static BigDecimal quantize(BigDecimal x,BigDecimal step,boolean up){
        if(step.signum()<=0)throw new IllegalArgumentException("非法步长");
        return x.divide(step,0,up?java.math.RoundingMode.CEILING:java.math.RoundingMode.FLOOR).multiply(step);
    }
    public synchronized BigDecimal tick(String symbol)throws Exception {
        return dec(filter(info(symbol),"PRICE_FILTER"),"tickSize");
    }
    public synchronized void validate(String symbol,String type,BigDecimal quantity,BigDecimal price,boolean opening,BigDecimal maxNotional)throws Exception{
        JSONObject details=info(symbol);
        JSONObject sizes=filter(details,type.equals("MARKET")?"MARKET_LOT_SIZE":"LOT_SIZE");
        BigDecimal minQty=dec(sizes,"minQty"),maxQty=dec(sizes,"maxQty"),step=dec(sizes,"stepSize");
        range(quantity,minQty,maxQty,"数量");
        if(quantity.remainder(step).signum()!=0)throw new IllegalArgumentException("数量步长必须为 "+step);
        BigDecimal expected=price;
        if(!type.equals("MARKET")){
            JSONObject tickRule=filter(details,"PRICE_FILTER");
            BigDecimal tick=dec(tickRule,"tickSize");
            range(price,dec(tickRule,"minPrice"),dec(tickRule,"maxPrice"),"价格");
            if(price.remainder(tick).signum()!=0)throw new IllegalArgumentException("价格最小跳动为 "+tick);
        }else{
            JSONObject p=obj("GET","/fapi/v1/premiumIndex",params("symbol",symbol),false);
            expected=new BigDecimal(p.getString("markPrice"));
        }
        BigDecimal notional=quantity.multiply(expected);
        if(opening&&notional.compareTo(maxNotional)>0)throw new IllegalArgumentException("超过单笔名义本金限制 "+maxNotional+" USDT，预计="+notional);
        JSONArray filters=details.getJSONArray("filters");
        for(int i=0;i<filters.length();i++){
            JSONObject f=filters.getJSONObject(i);
            if(opening&&f.optString("filterType").equals("MIN_NOTIONAL")&&notional.compareTo(dec(f,"notional"))<0)
                throw new IllegalArgumentException("低于交易所最小名义价值 "+f.getString("notional"));
        }
    }
    public synchronized void oneWay()throws Exception{
        JSONObject p=obj("GET","/fapi/v1/positionSide/dual",params(),true);
        if(p.optBoolean("dualSidePosition",true))throw new IllegalStateException("本版本只支持单向持仓模式；当前账户为双向持仓，未下单");
    }
    public synchronized BigDecimal positionAmt(String symbol)throws Exception{
        JSONArray positions=arr("/fapi/v2/positionRisk",params("symbol",symbol));
        for(int i=0;i<positions.length();i++){
            JSONObject p=positions.getJSONObject(i);
            if(p.getString("symbol").equals(symbol)&&p.optString("positionSide","BOTH").equals("BOTH"))
                return new BigDecimal(p.getString("positionAmt"));
        }
        return BigDecimal.ZERO;
    }
    public synchronized void ensureOpeningSide(String symbol,String side)throws Exception{
        BigDecimal amt=positionAmt(symbol);
        if((amt.signum()>0&&side.equals("SELL"))||(amt.signum()<0&&side.equals("BUY")))
            throw new IllegalStateException("已有反方向仓位，禁止开仓命令隐式平仓/反手；请使用 close");
    }
    public static String newId(){return "qp_"+UUID.randomUUID().toString().replace("-","").substring(0,24);}
    public synchronized JSONObject placeLimit(String symbol,String side,BigDecimal qty,BigDecimal price,String tif,
                                              boolean reduce,BigDecimal cap)throws Exception{
        oneWay();
        if(!reduce)ensureOpeningSide(symbol,side);
        validate(symbol,"LIMIT",qty,price,!reduce,cap);
        LinkedHashMap<String,String> p=params("symbol",symbol,"side",side,"type","LIMIT","quantity",qty.toPlainString(),
             "price",price.toPlainString(),"timeInForce",tif,"reduceOnly",Boolean.toString(reduce),"newClientOrderId",newId());
        return obj("POST","/fapi/v1/order",p,true);
    }
    public synchronized JSONObject placeMarket(String symbol,String side,BigDecimal qty,boolean reduce,BigDecimal cap)throws Exception{
        oneWay();if(!reduce)ensureOpeningSide(symbol,side);
        validate(symbol,"MARKET",qty,BigDecimal.ZERO,!reduce,cap);
        return obj("POST","/fapi/v1/order",params("symbol",symbol,"side",side,"type","MARKET",
            "quantity",qty.toPlainString(),"reduceOnly",Boolean.toString(reduce),"newClientOrderId",newId()),true);
    }
    public synchronized JSONObject protection(String symbol,String kind,BigDecimal trigger,String working,
                                             BigDecimal callback,BigDecimal activate)throws Exception{
        oneWay();BigDecimal pos=positionAmt(symbol);
        if(pos.signum()==0)throw new IllegalStateException("没有持仓，不能创建只平仓保护单");
        String side=pos.signum()>0?"SELL":"BUY";
        LinkedHashMap<String,String> p=params("symbol",symbol,"algoType","CONDITIONAL","side",side,
             "type",kind,"workingType",working,"clientAlgoId",newId());
        if(kind.equals("TRAILING_STOP_MARKET")){
            p.put("quantity",pos.abs().stripTrailingZeros().toPlainString());
            p.put("callbackRate",callback.toPlainString());
            if(activate!=null)p.put("activatePrice",activate.toPlainString());
        }else{
            p.put("closePosition","true");p.put("triggerPrice",trigger.toPlainString());
            if(trigger.remainder(tick(symbol)).signum()!=0)throw new IllegalArgumentException("触发价不符合 tickSize="+tick(symbol));
        }
        return obj("POST","/fapi/v1/algoOrder",p,true);
    }
}
