package com.quantpilot.terminal;

import java.nio.charset.StandardCharsets;
import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;

public final class Sign {
    private Sign() {}
    public static String hmac(String data,String secret) {
        try {
            Mac mac=Mac.getInstance("HmacSHA256");
            mac.init(new SecretKeySpec(secret.getBytes(StandardCharsets.UTF_8),"HmacSHA256"));
            byte[] digest=mac.doFinal(data.getBytes(StandardCharsets.UTF_8));
            char[] hex="0123456789abcdef".toCharArray();
            StringBuilder b=new StringBuilder(digest.length*2);
            for(byte x:digest){b.append(hex[(x&255)>>4]);b.append(hex[x&15]);}
            return b.toString();
        }catch(Exception e){throw new IllegalStateException(e);}
    }
}
