package com.quantpilot.terminal;

import java.math.BigDecimal;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;
import java.util.Set;

/** Whitelisted trading verbs only; this terminal never executes OS/shell commands. */
public final class Grammar {
    private Grammar() {}
    public record Cmd(String verb, List<String> args) {
        public String arg(int i) { return args.get(i); }
        public int size() { return args.size(); }
    }
    private static final Set<String> VERBS=Set.of(
      "help","clear","status","refresh","env","auth","logout","ping","time","risk",
      "price","mark","book","funding","rules","balance","positions","position","orders","algos",
      "order","algo","history","fills","income","positionmode",
      "long","short","buy","sell","limit","market","close","spike","ladder",
      "sl","tp","trail","cancel","cancelall","cancelalgo","cancelalgos","cancelboth",
      "flatten","leverage","margin","confirm","abort");
    public static Cmd parse(String raw) {
        if(raw==null||raw.isBlank())throw new IllegalArgumentException("空命令；输入 help");
        if(raw.length()>260)throw new IllegalArgumentException("命令过长");
        if(!raw.matches("[\\p{Alnum}._%+\\-\\s]+"))throw new IllegalArgumentException("非法字符；不支持 Shell、管道、脚本或 URL");
        String[] bits=raw.trim().split("\\s+");
        String verb=bits[0].toLowerCase(Locale.ROOT);
        if(!VERBS.contains(verb))throw new IllegalArgumentException("未知指令 "+bits[0]+"；输入 help");
        return new Cmd(verb,Arrays.asList(Arrays.copyOfRange(bits,1,bits.length)));
    }
    public static void count(Cmd c,int min,int max) {
        if(c.size()<min||c.size()>max)throw new IllegalArgumentException("参数数目不正确；help "+c.verb());
    }
    public static String symbol(String value) {
        String s=value.toUpperCase(Locale.ROOT);
        if(!s.matches("[A-Z0-9]{2,24}USDT"))throw new IllegalArgumentException("仅支持 USDT 合约，如 DOGEUSDT");
        return s;
    }
    public static String side(String s) {
        String u=s.toUpperCase(Locale.ROOT);
        if(!u.equals("BUY")&&!u.equals("SELL")&&!u.equals("LONG")&&!u.equals("SHORT"))
            throw new IllegalArgumentException("方向必须 BUY/SELL 或 LONG/SHORT");
        return (u.equals("LONG")||u.equals("BUY"))?"BUY":"SELL";
    }
    public static BigDecimal dec(String value) {
        if(!value.matches("[0-9]{1,12}(?:\\.[0-9]{1,12})?"))throw new IllegalArgumentException("请输入普通正小数");
        BigDecimal v=new BigDecimal(value);
        if(v.signum()<=0)throw new IllegalArgumentException("数值必须大于零");
        return v;
    }
    public static int integer(String value,int min,int max) {
        if(!value.matches("[0-9]{1,3}"))throw new IllegalArgumentException("整数参数无效");
        int v=Integer.parseInt(value);
        if(v<min||v>max)throw new IllegalArgumentException("整数必须在 "+min+" 至 "+max+" 之间");
        return v;
    }
    public static String tif(String s) {
        String x=s.toUpperCase(Locale.ROOT);
        if(!Set.of("GTX","GTC","IOC","FOK").contains(x))throw new IllegalArgumentException("有效方式：GTX/GTC/IOC/FOK");
        return x;
    }
    public static String text(){return """
      基础: help [trade|query|risk] · status · refresh · clear · env demo|live · auth · logout
      行情: price/mark/book/funding/rules SYMBOL
      账户: balance · positions · position SYMBOL · orders [SYMBOL] · algos [SYMBOL]
      下单: long/short SYMBOL 数量 限价 · limit SYMBOL BUY|SELL 数量 价格 [gtx|gtc|ioc|fok]
      市价: market SYMBOL BUY|SELL 数量 · close SYMBOL all|数量 market|价格
      插针: spike SYMBOL long|short 数量 偏离百分比
      梯单: ladder SYMBOL long|short 总数量 起价 止价 档数
      保护: sl/tp SYMBOL 触发价 [mark|last] · trail SYMBOL 回调百分比 [激活价]
      撤单: cancel SYMBOL ID · cancelall SYMBOL · cancelalgo SYMBOL ID · cancelalgos SYMBOL
      强制: cancelboth SYMBOL · flatten SYMBOL
      配置: risk [最大单笔名义本金] · leverage SYMBOL 倍数 · margin SYMBOL isolated|cross
      历史: order/algo SYMBOL ID · history/fills/income SYMBOL · positionmode
      每笔写入操作必须 confirm；主网切换需要 confirm LIVE；abort 取消
      """;}
}
