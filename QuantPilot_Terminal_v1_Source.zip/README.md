# QuantPilot Terminal v1.0 — 安卓币安合约命令终端

> **交付形式：Android Studio 源码工程。** 本次环境没有 Android SDK / Gradle，尚未生成可安装的 APK，也没有使用真实币安 API Key 做端到端实盘验证。项目已经包含 GitHub Actions 自动构建 Debug APK 的工作流。先在 DEMO 测试账号完成完整验证，不要直接把未经实机测试的程序投入真金白银交易。

## 1. 产品范围（严格精简）

只有一个界面，**没有按钮导航、交易图表、自动策略页面、机器人开关、币种排行榜，也没有后台自动下单**。

```text
┌────────────────────────────────────────┐
│ 当前委托  12（普通+条件） · DEMO       │
│ 当前持仓  2                           │
│ DOGEUSDT LONG 100 entry=... pnl=...    │
│ ...                                    │
├────────────────────────────────────────┤
│ QuantPilot Terminal v1                 │
│ > orders DOGEUSDT                      │
│ [Binance 订单查询结果]                 │
│ > short DOGEUSDT 100 0.25              │
│ 待确认 [45秒] ...                      │
│ > confirm                              │
│ [Binance 下单响应]                     │
│                                        │
├────────────────────────────────────────┤
│ > 输入命令后按回车                     │
└────────────────────────────────────────┘
```

- 顶部 **当前委托数** = 普通未完成订单 + 条件未完成订单。这些必须分别查询 `/fapi/v1/openOrders`、`/fapi/v1/openAlgoOrders`；不是最近订单数量。
- **当前持仓** = 币安返回的非零持仓数量，显示币种、方向、仓位数量、开仓均价、标记价及浮动盈亏。更多可输入 `positions`。
- 仅当 APK **在前台显示且已配置密钥**时，约每 30 秒刷新一次；也可输入 `refresh`。断网或 API 请求出错显示 `?`，不会错误显示 0。
- 下方只有命令历史输出区和一行命令输入框；**不提供 Shell/系统命令执行**，也不执行脚本、管道、任意 HTTP URL。
- 不会在后台自动交易。App 关闭/断线不代表币安侧已挂委托自动取消；交易所端的保护单可继续留存。

## 2. 如何构建 APK

### Android Studio
1. 安装 Android Studio、**JDK 17**，Android SDK Platform **35**、Build Tools **35**。
2. 解压工程，用 Android Studio 打开包含 `settings.gradle` 的 `QuantPilot_Terminal_v1` 目录。
3. 使用 Android Gradle Plugin **8.7.3** / Gradle **8.9** 同步。源码包没有 Gradle Wrapper JAR；可在 IDE 中选本地 Gradle 8.9 或生成 Wrapper。
4. 菜单选择 `Build > Build APK(s)`。
5. 生成文件通常位于 `app/build/outputs/apk/debug/app-debug.apk`；传到 Android 8.0+ 手机安装。

### GitHub Actions（电脑上不安装 SDK）
1. 新建私有 GitHub 仓库，把这个工程的内容上传到仓库**根目录**（包含 `.github/workflows/android.yml`）。
2. 打开 `Actions > Build Android debug APK > Run workflow`。
3. 成功之后在此次 workflow 的 `Artifacts` 下载 `QuantPilot-Terminal-v1-debug-apk`，解压得到 `app-debug.apk`。
4. Debug APK 非正式发行签名，升级时要保持同一签名，否则需先卸载（卸载不会撤掉交易所委托）。**不要将 API 密钥提交到 GitHub！**

本次无法在当前环境执行完整 Android 构建，因此以上两个流程**未经本次实际运行验证**。如遇构建错误，请将完整错误日志发回修正。

## 3. 第一次连接与环境切换

App 启动默认为 **DEMO**，且没有保存 API Key。

```text
status
ping
auth
balance
positions
orders
algos
refresh
```

`auth` 会弹出两个遮蔽输入框供你填写当前环境的 API Key 和 Secret。**千万不要在终端中写 `auth KEY SECRET`**。它们只保存在 APP 进程内存里，不写入源码、数据库、日志、配置文件。退出程序进程或者 `logout` 后需重新认证。手机系统/设备已被入侵时仍可能泄露密钥；优先使用受限权限、无提现权、专门测试账户的 Key。

如需显式切换 DEMO：

```text
env demo
auth
```

主网真实资金模式，需要两步确认并重新认证：

```text
env live
confirm LIVE
auth
status
```

`env live` 本身**不发送订单**。但此后所有 `confirm` 的写操作将指向真实环境 `https://fapi.binance.com`。确认 LIVE 不可缩写、不可误触；程序会清空之前的 DEMO 凭据。**主网不应在完成 DEMO 功能及异常处理验证之前使用。**

## 4. 全部命令索引

### 4.1 基础、环境与安全

| 命令 | 含义 |
|---|---|
| `help` | 所有命令简表 |
| `help trade` / `help query` / `help risk` | 分类实例 |
| `status` | DEMO/LIVE、认证状态、本次限额、是否有待确认指令 |
| `ping` / `time` | 网络连通 / 交易所服务器时间 |
| `auth` | 安全弹窗输入 API Key + Secret |
| `logout` | 从运行内存清除密钥；**不撤单** |
| `env demo` | 切 DEMO 并清空原密钥 |
| `env live` + `confirm LIVE` | 切 LIVE 并清空原密钥；真实资金危险 |
| `risk` | 查看单笔新开仓名义本金上限（默认 **20 USDT**） |
| `risk 80` + `confirm` | 本次会话上限改为 80 USDT；允许 5~500 USDT，重启恢复 20 |
| `refresh` | 手动刷新顶部两个实时状态 |
| `clear` | 清除终端显示文本（不撤单、不平仓） |
| `abort` | 放弃待确认操作 |
| `confirm` | 45 秒内确认一次有状态变化的指令，**失败后不自动重发** |

### 4.2 实时信息、账户和历史

| 命令 | 内容 |
|---|---|
| `price DOGEUSDT` | 最新成交参考价 |
| `mark DOGEUSDT` | 标记价格、指数价格、资金费率等 |
| `book DOGEUSDT` | 当前最优买/卖报价及数量 |
| `funding DOGEUSDT` | 当前行情返回的资金费率字段（非历史列表） |
| `rules DOGEUSDT` | 交易对价格精度、数量步长、最小名义金额及各类过滤器 |
| `balance` | 账户余额详情 |
| `positions` | 所有非零持仓及浮盈亏 |
| `position DOGEUSDT` | 单合约非零仓位 |
| `orders` / `orders DOGEUSDT` | 普通未成交委托（全账户或指定币） |
| `algos` / `algos DOGEUSDT` | 条件单，包括止损、止盈、追踪止损 |
| `order DOGEUSDT 12345` | 订单 ID 单笔详情 |
| `algo DOGEUSDT 12345` | 条件单 ID 单笔详情 |
| `history DOGEUSDT` | 最近最多 20 条普通订单记录 |
| `fills DOGEUSDT` | 最近最多 20 条成交记录 |
| `income DOGEUSDT` | 最近最多 20 条资金收支记录 |
| `positionmode` | 当前是否处于双向持仓（本版**不支持双向模式交易**） |

### 4.3 下单：Maker / 市价 / IOC / FOK

```text
long  DOGEUSDT 100 0.105
short DOGEUSDT 100 0.205
buy   DOGEUSDT 100 0.105
sell  DOGEUSDT 100 0.205
```

四条分别为限价 BUY 或限价 SELL，默认 `GTX`（Post Only，只当挂单方；若将立即吃单可被交易所拒绝）。**数量是基础资产个数，不是 USDT 金额**；例如 `100` 表示 100 DOGE，价格单位 USDT/DOGE。

自定义限价单与执行方式：

```text
limit DOGEUSDT buy 100 0.105 gtx
limit DOGEUSDT sell 100 0.205 gtc
limit DOGEUSDT sell 100 0.205 ioc
limit DOGEUSDT buy 100 0.105 fok
```

直接市价开仓（有滑点和吃单手续费，提交前显示特别提示）：

```text
market DOGEUSDT buy 100
market DOGEUSDT sell 100
```

**开仓与平仓都要求二次确认：** `long ...` -> 先显示预览；用户再次输入 `confirm` 才真正发送。确认后**“收到委托”不等于“成交”**，须查看 `order`、`orders`、`fills`、`position`。

### 4.4 插针捡漏：极端价埋伏

```text
spike DOGEUSDT short 100 18
spike DOGEUSDT long 100 15
```

- 第一个：以**当前标记价**为参考，在约 **+18%** 的极端价格预置 `SELL LIMIT GTX` 开空。
- 第二个：在标记价约 **-15%** 的价格预置 `BUY LIMIT GTX` 开多。
- 支持 0.1%—50% 偏离，仅发出**单笔挂单**，不是全天候自动寻找币种或定期移动挂单。
- 价格根据对应交易对 `tickSize` 取整：做空向上取整、做多向下取整。
- **交易所 `PERCENT_PRICE` 等过滤器可能拒绝过远价格**。价格偏离过大不意味着一定能挂出去。
- **此命令不会自动附上止盈止损**。订单成交后需你通过 `sl`、`tp`、`close` 等命令另行管理；APP 退出后不会自动帮你平仓。极端单边行情可能造成远超预期的亏损。

### 4.5 阶梯限价单

```text
risk 100
confirm
ladder DOGEUSDT long 500 0.090 0.080 5
confirm
```

- `总数量` 是所有档位的基础资产总数量，档位数 2—10；按交易所 `stepSize` 向下取整成相同每档数量，余量**不会再分配**。
- 每档是 `LIMIT GTX`。预览显示实际档位和预估总名义金额。
- 总名义金额以及每档单独都做限额/步长/最小金额校验；默认 20 USDT 的小额度可能容纳不了多档，需要先调整 `risk`（最高 500 USDT）。
- **多档提交不是原子事务**：中途失败不回滚前面已成功发送的单；结果会提示成功档数，必须再查 `orders` 核实。

### 4.6 平仓 / 交易所端止损止盈

```text
close DOGEUSDT all market
close DOGEUSDT 100 market
close DOGEUSDT all 0.115
close DOGEUSDT 100 0.115
```

- `close` 自动读取**币安当前单向净仓位**，确定应 BUY 还是 SELL，使用 `reduceOnly=true` 避免扩大反向仓位。`market` 是市价单，数值是限价 GTX；`all` 指查询时的全部非零持仓。
- `close` **不会同时自动取消**此币种已有的其他开仓单或保护单；如要撤干净再平请使用 `flatten`。

```text
sl DOGEUSDT 0.080 mark
tp DOGEUSDT 0.118 last
trail DOGEUSDT 1.5
trail DOGEUSDT 1.5 0.125
```

- `sl`: `STOP_MARKET`；`tp`: `TAKE_PROFIT_MARKET`。二者使用 2026 当前独立的 **`POST /fapi/v1/algoOrder`** 接口，并带 `algoType=CONDITIONAL`、`triggerPrice`、`closePosition=true`。**不是旧的 `/fapi/v1/order`**。
- `mark` 使用标记价格触发；`last` 使用最新合约价格触发，默认 `mark`。
- `trail`: `TRAILING_STOP_MARKET`；回调百分比取 0.1—10，数量为提交时读取的现有仓位绝对数量；有可选激活价。
- 程序必须确认币种存在当前非零持仓才能放保护单，但**不自动撤掉已有止损单/止盈单**，且多张保护单可能互相冲突。用 `algos SYMBOL` 查是否重复；用户自行管理。
- 无法保证触发后的实际成交价；交易所条件单可能因为风控、价格条件或仓位变化而被拒绝或失效。

### 4.7 撤单与紧急操作

```text
cancel DOGEUSDT 123456      # 撤单个普通限价单
cancelall DOGEUSDT         # 撤此币全部普通挂单，保留条件单
cancelalgo DOGEUSDT 234567  # 撤单个条件单
cancelalgos DOGEUSDT       # 撤此币全部条件单（可能撤掉止损！）
cancelboth DOGEUSDT        # 全撤普通单和条件单
flatten DOGEUSDT           # 全撤两类单，再市价 reduceOnly 平此币净持仓
```

- 每个操作先预览，输入 `confirm` 才执行。
- `flatten` 是顺序非原子操作：先普通单全撤 → 条件单全撤 → 查询持仓 → 市价只减仓平仓。网络中断可能让操作只完成一部分。**出现报错后一定要查 `orders`、`algos`、`position` 核实**；绝不假称已全部平仓。
- `cancelboth` 只撤订单，**不平已有仓位**；可能让已有仓位失去保护性止损。

### 4.8 杠杆和保证金模式

```text
leverage DOGEUSDT 3
margin DOGEUSDT isolated
margin DOGEUSDT cross
```

更改此币杠杆（本版限制 1—10x）或保证金模式，须 `confirm`。交易所可能因为仓位或委托状态禁止切换。**切换杠杆并不保证风险只相当于本金的几分之一。**

## 5. 必须知道的限制

1. **单向仓位 only**：程序会查询 `GET /fapi/v1/positionSide/dual`。双向持仓账户的写单会拒绝；程序不会偷偷帮你更改账户持仓模式。已有反向净仓位时，`long/short/market` 不会绕过 `close` 偷偷反手。
2. **没有无条件自动止盈**：挂上插针单后手机关机仍可成交，而 APP 不会醒来自动平仓；如需真正无人值守插针止盈，需要交易所端条件单或可靠后台服务，不能靠这个纯前台命令行保证。
3. **API 时间 / 规则**：签名带 Binance 服务器时间校准、`recvWindow=5000`，新开仓校验现时交易对、价格 tick、数量 step、最小名义金额；交易所仍可拒绝下单（例如动态 `PERCENT_PRICE`、订单数、仓位限制、无余额、未授权）。
4. **市价额度只作预估**：本版用最新标记价格估计名义本金，并非实际成交成本、保证金或滑点上限；仓位可能在极端行情发生强平或超额损失。
5. **订单确认机制**：订单预览 45 秒有效，每次只能有一个待确认操作；确认时若发生网络超时，交易所是否收到委托可能不明。**不会自动重新发送**；先查成交/订单，避免重复。
6. **数量与价**：所有 `qty` 都是基础币种数量、所有 `price` 都是合约报价价格，不能混用 USDT 金额、保证金与合约数量。
7. **状态刷新**：普通单和条件单全市场查询有请求权重成本，约 30 秒前台轮询；没有长期 WebSocket 推送，看到的数量可能比真实状态滞后，查询失败标 `?`。无独立后台服务。
8. **交易所策略规则**：用户自行确认区域合规、账户是否有权限使用币安 USDT 永续、API IP 限制、订单数量限制、风险敞口。请勿向任何人泄露密钥。
9. **权限**：仅声明 `INTERNET`。不开文件、相机、短信、麦克风、定位权限；`FLAG_SECURE` 防一般截图/录屏，`android:allowBackup=false`。这些不能替代完整安全审计。
10. **版本范围**：只覆盖 Binance USDT 永续的常用接口，不支持币本位、现货、统一账户 Portfolio Margin 专用 API、双向 Hedge、多账户、OCO 原子保护、自动重挂、后台抢单。

## 6. 自测方法

源码附带不需要 Android SDK 的纯 Java 解析器与签名自测（需 JDK 17）：

```bash
mkdir -p /tmp/qpt-classes
javac -encoding UTF-8 -d /tmp/qpt-classes \
  app/src/main/java/com/quantpilot/terminal/Grammar.java \
  app/src/main/java/com/quantpilot/terminal/Sign.java \
  tools/GrammarSelfTest.java
java -cp /tmp/qpt-classes GrammarSelfTest

# EngineSelfTest 还需把 FuturesApi / TerminalEngine 与 org.json 库编译进 classpath；
# 该检查在制作环境用仅供测试的 org.json 替身完成，
# 这些替身文件未打包进 Android 项目。
```

本次完成了 **46 项纯 Java 检查**（25 项命令识别/数值解析/恶意 Shell 命令拒绝/HMAC-SHA256 签名检查，21 项配置预览、二次确认及 LIVE 环境防误切换检查），并使用只具备接口签名的本地替身完成了安卓 Activity + Java 后端的编译一致性检查。替身编译不等于真正的 Android SDK 编译。没有 API Key 和完整 Android 构建环境，不能声称 Binance 真正下单成功或 APK 能安装运行；需在手机和 Demo 环境继续验证。

## 7. 币安接口依据（2026 年资料）

- [Binance USDⓈ-M REST Trade API](https://developers.binance.com/en/docs/catalog/core-trading-derivatives-trading-usd-s-m-futures/api/rest-api/trade)；`POST /fapi/v1/order` / `DELETE /fapi/v1/order` 等。
- [Binance API 公共定义、订单类型与过滤器](https://developers.binance.com/zh-CN/docs/products/derivatives-trading-usds-futures/common-definition)（含 GTX、MIN_NOTIONAL、PERCENT_PRICE）。
- [Binance 条件止损迁移及当前 Algo 接口](https://developers.binance.com/zh-CN/docs/catalog/core-trading-derivatives-trading-usd-s-m-futures/api/rest-api/trade)（以实际官方文档为准）。
- [Binance 开发更新日志](https://developers.binance.com/zh-CN/docs/products/derivatives-trading-coin-futures/change-log)（含 v3 账户和条件单改动）。

**本项目是技术实现，不是收益承诺。合约可能因插针、缺乏流动性、杠杆和爆仓导致本金全部损失甚至额外费用。**
